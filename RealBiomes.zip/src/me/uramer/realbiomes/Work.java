package me.uramer.realbiomes;

import com.google.gson.internal.Pair;

import java.util.HashMap;

/**
 * Created with IntelliJ IDEA.
 * User: Anton
 * Date: 02.06.12
 * Time: 1:23
 * To change this template use File | Settings | File Templates.
 */
public class Work implements Runnable {
    private RBPlayer player;

    public Work(RBPlayer p) {
        player=p;
    }

    @Override
    public void run() {

    }
}
