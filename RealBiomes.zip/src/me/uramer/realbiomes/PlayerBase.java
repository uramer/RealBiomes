package me.uramer.realbiomes;

import java.util.HashMap;

/**
 * Created with IntelliJ IDEA.
 * User: Anton
 * Date: 02.06.12
 * Time: 0:53
 * To change this template use File | Settings | File Templates.
 */
public class PlayerBase {
    private HashMap<String,RBPlayer>  map;

    public PlayerBase(Config config) {
     map=new HashMap<String, RBPlayer>(config.initialMapSize);
    }

    public RBPlayer get(String name) {
        if(map.containsKey(name)) return map.get(name);
        else return null;
    }

    public void set(String name,RBPlayer player) {
        map.put(name,player);
    }
}
