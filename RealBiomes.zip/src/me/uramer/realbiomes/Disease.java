package me.uramer.realbiomes;

import org.bukkit.configuration.ConfigurationSection;

import java.util.ArrayList;

/**
 * Created with IntelliJ IDEA.
 * User: Anton
 * Date: 02.06.12
 * Time: 1:35
 * To change this template use File | Settings | File Templates.
 */
public class Disease {
    ArrayList<State> states;

    public Disease(ConfigurationSection config) {

    }
}
