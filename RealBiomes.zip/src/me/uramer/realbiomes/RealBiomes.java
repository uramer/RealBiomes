package me.uramer.realbiomes;

import org.bukkit.Server;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitScheduler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Created with IntelliJ IDEA.
 * User: Anton
 * Date: 01.06.12
 * Time: 17:51
 * To change this template use File | Settings | File Templates.
 */
public class RealBiomes extends JavaPlugin {
    Logger logger=this.getLogger();
    Config config;
    PlayerBase players;
    Server server;
    BukkitScheduler scheduler;

    public void log(String s) {
        logger.log(Level.INFO, String.format("[RealBiomes] %s",s));
    }

    @Override
    public void onEnable() {
        config=new Config(this.getConfig());
        players=new PlayerBase(config);
        server=getServer();
        scheduler=server.getScheduler();
        log("Enabled!");
    }

    @Override
    public void onDisable() {
        log("Disabled");
    }

    public void onPlayerLogin(PlayerLoginEvent event) {
        String name=event.getPlayer().getName();
        RBPlayer player=players.get(name);
        if(player==null) {
            players.set(name,new RBPlayer(server.getPlayer(name)));
        }
        scheduler.scheduleAsyncRepeatingTask(this,new Work(player),config.delay,config.delay);

    }

}
